# Política de Privacidade (Modelo)

Este aplicativo armazena localmente no dispositivo:
- PIN de acesso (criptografado com SharedPreferences)
- Histórico de cálculos (valores, estado, data e hora)

Não coletamos dados pessoais nem enviamos informações a servidores externos.
Você pode limpar o histórico e redefinir o PIN no menu Configurações.
