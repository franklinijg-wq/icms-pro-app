import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/icms_service.dart';

class LockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const LockScreen({super.key, required this.onUnlocked});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final ctrl = TextEditingController();
  String? error;

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Desbloquear')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Digite seu PIN', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              obscureText: true,
              maxLength: 6,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                hintText: 'Ex.: 1234',
                errorText: error,
              ),
              onSubmitted: (_) => _validate(context),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => _validate(context),
                child: const Text('Entrar'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _validate(BuildContext context) async {
    final ok = await context.read<IcmsService>().validatePin(ctrl.text);
    if (ok) {
      widget.onUnlocked();
    } else {
      setState(() => error = 'PIN incorreto');
    }
  }
}
