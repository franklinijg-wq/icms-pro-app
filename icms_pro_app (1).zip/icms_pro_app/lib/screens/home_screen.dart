import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/icms_service.dart';
import 'tabela_screen.dart';
import 'calculadora_screen.dart';
import 'history_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;
  final bool firstRun;
  const HomeScreen({super.key, required this.onToggleTheme, this.firstRun = false});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    // On first run, set PIN
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (widget.firstRun) {
        await _askPin();
      }
    });
  }

  Future<void> _askPin() async {
    final ctrl = TextEditingController();
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Definir PIN'),
        content: TextField(
          controller: ctrl,
          obscureText: true,
          maxLength: 6,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'Crie um PIN (ex.: 1234)',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Pular')),
          FilledButton(
            onPressed: () async {
              if (ctrl.text.isNotEmpty) {
                await context.read<IcmsService>().setPin(ctrl.text);
              }
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Salvar'),
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ICMS Pro'),
        actions: [
          IconButton(
            tooltip: 'Histórico',
            icon: const Icon(Icons.history),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen())),
          ),
          IconButton(
            tooltip: 'Configurações',
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(onToggleTheme: widget.onToggleTheme))),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Consultar'),
            Tab(text: 'Calculadora'),
            Tab(text: 'Sobre'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          TabelaScreen(),
          CalculadoraScreen(),
          _AboutTab(),
        ],
      ),
    );
  }
}

class _AboutTab extends StatelessWidget {
  const _AboutTab();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Text('ICMS Pro — consulta de alíquotas e calculadora com histórico. \nEste app não envia dados para servidores externos.'),
      ),
    );
  }
}
