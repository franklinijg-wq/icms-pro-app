import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/icms_service.dart';
import '../models/state_rate.dart';

class TabelaScreen extends StatefulWidget {
  const TabelaScreen({super.key});

  @override
  State<TabelaScreen> createState() => _TabelaScreenState();
}

class _TabelaScreenState extends State<TabelaScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final service = context.watch<IcmsService>();
    final List<StateRate> data = service.search(query);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Buscar por estado ou UF...',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
            ),
            onChanged: (v) => setState(() => query = v),
          ),
        ),
        Expanded(
          child: ListView.separated(
            itemCount: data.length,
            separatorBuilder: (_, __) => const Divider(height: 0),
            itemBuilder: (context, i) {
              final s = data[i];
              return ListTile(
                leading: CircleAvatar(child: Text(s.uf)),
                title: Text(s.estado),
                subtitle: Text('Alíquota interna: ${s.aliquota.toStringAsFixed(2)}%'),
              );
            },
          ),
        ),
      ],
    );
  }
}
