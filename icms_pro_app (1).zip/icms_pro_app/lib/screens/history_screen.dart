import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../services/icms_service.dart';
import '../models/calc_history_item.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<CalcHistoryItem> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await context.read<IcmsService>().loadHistory();
    setState(() => items = list);
  }

  @override
  Widget build(BuildContext context) {
    final dateFmt = DateFormat('dd/MM/yyyy HH:mm', 'pt_BR');
    return Scaffold(
      appBar: AppBar(
        title: const Text('Histórico'),
        actions: [
          IconButton(
            tooltip: 'Exportar CSV',
            icon: const Icon(Icons.ios_share),
            onPressed: items.isEmpty ? null : _exportCsv,
          ),
          IconButton(
            tooltip: 'Limpar',
            icon: const Icon(Icons.delete),
            onPressed: items.isEmpty ? null : () async {
              await context.read<IcmsService>().clearHistory();
              await _load();
            },
          ),
        ],
      ),
      body: items.isEmpty
        ? const Center(child: Text('Sem itens salvos.'))
        : ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 0),
            itemBuilder: (_, i) {
              final it = items[i];
              return ListTile(
                title: Text('${it.estado} (${it.uf}) — ${it.aliquota.toStringAsFixed(2)}%'),
                subtitle: Text('${dateFmt.format(it.timestamp)}  •  Base: R\$ ${it.base.toStringAsFixed(2)}  •  ICMS: R\$ ${it.icms.toStringAsFixed(2)}  •  Total: R\$ ${it.total.toStringAsFixed(2)}'),
              );
            },
          ),
    );
  }

  Future<void> _exportCsv() async {
    final rows = [
      ['timestamp','uf','estado','base','aliquota','icms','total'],
      ...items.map((e) => [
        e.timestamp.toIso8601String(),
        e.uf, e.estado,
        e.base.toStringAsFixed(2),
        e.aliquota.toStringAsFixed(2),
        e.icms.toStringAsFixed(2),
        e.total.toStringAsFixed(2),
      ])
    ];
    final csv = rows.map((r) => r.map(_escape).join(',')).join('\n');
    final xfile = XFile.fromData(utf8.encode(csv), mimeType: 'text/csv', name: 'historico_icms.csv');
    await Share.shareXFiles([xfile], text: 'Histórico ICMS');
  }

  String _escape(String v) {
    if (v.contains(',') || v.contains('\n') || v.contains('"')) {
      return '"' + v.replaceAll('"', '""') + '"';
    }
    return v;
  }
}
