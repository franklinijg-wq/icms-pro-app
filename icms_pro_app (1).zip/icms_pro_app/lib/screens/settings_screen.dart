import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../services/icms_service.dart';

class SettingsScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;
  const SettingsScreen({super.key, required this.onToggleTheme});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String version = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final info = await PackageInfo.fromPlatform();
    setState(() => version = '${info.version}+${info.buildNumber}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.brightness_6),
            title: const Text('Alternar tema'),
            onTap: widget.onToggleTheme,
          ),
          ListTile(
            leading: const Icon(Icons.vpn_key),
            title: const Text('Redefinir PIN'),
            onTap: () async {
              await context.read<IcmsService>().resetPin();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN apagado. Defina um novo no próximo acesso.')));
              }
            },
          ),
          const Divider(),
          ListTile(
            title: const Text('Versão do app'),
            subtitle: Text(version.isEmpty ? '-' : version),
          ),
          ListTile(
            title: const Text('Política de Privacidade'),
            subtitle: const Text('Consulte o arquivo PRIVACY_POLICY.md incluído no app.'),
          ),
        ],
      ),
    );
  }
}
