class StateRate {
  final String uf;
  final String estado;
  final double aliquota;

  StateRate({required this.uf, required this.estado, required this.aliquota});

  factory StateRate.fromJson(Map<String, dynamic> j) => StateRate(
        uf: j['uf'],
        estado: j['estado'],
        aliquota: (j['aliquota'] as num).toDouble(),
      );

  Map<String, dynamic> toJson() => {'uf': uf, 'estado': estado, 'aliquota': aliquota};
}
